package model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;


/**
 * DAO(Data Access Object):データベースへのアクセスを行うクラスを作り、そのクラスを通してデータベースへアクセスするデザインパターン
 * 
 */
public class ShainDAO {

    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("IH13A06_JV31_29_06_PU");

    public List<Shain> search(String name, String gender, String note, String sort, String order) {
        EntityManager em = emf.createEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Shain> cq = cb.createQuery(Shain.class);
            Root<Shain> root = cq.from(Shain.class);

            List<Predicate> predicates = new ArrayList<>();

            if (name != null && !name.isEmpty()) {
                predicates.add(cb.like(root.get("name"), "%" + name + "%"));
            }
            if (gender != null && !gender.isEmpty()) {
                predicates.add(cb.equal(root.get("gender"), gender));
            }
            if (note != null && !note.isEmpty()) {
                predicates.add(cb.like(root.get("note"), "%" + note + "%"));
            }

            cq.where(predicates.toArray(new Predicate[0]));

            // SQLインジェクション対策
            if (!("id".equals(sort) || "name".equals(sort) || "gender".equals(sort) || "note".equals(sort))) {
                sort = "id";
            }
            if (!("asc".equalsIgnoreCase(order) || "desc".equalsIgnoreCase(order))) {
                order = "asc";
            }

            if ("asc".equalsIgnoreCase(order)) {
                cq.orderBy(cb.asc(root.get(sort)));
            } else {
                cq.orderBy(cb.desc(root.get(sort)));
            }

            return em.createQuery(cq).getResultList();
        } finally {
            em.close();
        }
    }
    
    public void save(Shain shain) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(shain);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public Shain findById(int id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Shain.class, id);
        } finally {
            em.close();
        }
    }

    public void update(Shain shain) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(shain);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void delete(int id) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Shain s = em.find(Shain.class, id);
            if (s != null) {
                em.remove(s);
            }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    
}
